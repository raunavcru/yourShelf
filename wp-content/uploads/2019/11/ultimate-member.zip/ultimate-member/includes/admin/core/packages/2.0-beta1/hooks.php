<?php

return array(
	'styles20beta1'            => 'styles20beta1',
	'user_roles20beta1'        => 'user_roles20beta1',
	'get_users_per_role20beta1'       => 'get_users_per_role20beta1',
	'update_users_per_page20beta1'    => 'update_users_per_page20beta1',
	'email_templates20beta1'   => 'email_templates20beta1',
	'settings20beta1'          => 'settings20beta1',


	'content_restriction20beta1'      => 'content_restriction20beta1',
	'menus20beta1'                    => 'menus20beta1',
	'mc_lists20beta1'                 => 'mc_lists20beta1',
	'social_login20beta1'             => 'social_login20beta1',
	'cpt20beta1'                      => 'cpt20beta1',

	'get_forums20beta1'               => 'get_forums20beta1',
	'update_forum_per_page20beta1'    => 'update_forum_per_page20beta1',
	'get_products20beta1'             => 'get_products20beta1',
	'update_products_per_page20beta1' => 'update_products_per_page20beta1',
);